"""
Simple IP Logger - Internship Project
--------------------------------------
What this does:
- When someone visits the home page ("/"), the server records their
  IP address, browser info (user agent), and the time of visit.
- All visits are saved in a local SQLite database (logs.db).
- A "/dashboard" page shows all the logged visits in a nice table,
  and lets you refresh/clear the data using JavaScript (AJAX calls).

Tech used: Python (Flask) + HTML + CSS + JavaScript -> exactly what you wanted.

NOTE on ethics/legality:
This logs visitors to a page YOU own and control (like basic website
analytics). Don't use this to secretly track people via disguised
links sent to others without their knowledge - that crosses into
deanonymizing people without consent, which is a misuse of this kind
of tool. Always disclose to visitors that their IP/visit is logged
(see the small notice on the demo page).
"""

from flask import Flask, render_template, request, jsonify
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)

DB_FILE = os.path.join(os.path.dirname(__file__), "logs.db")


def init_db():
    """Create the logs table if it doesn't already exist."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT,
            user_agent TEXT,
            visited_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def get_visitor_ip():
    """
    Get the visitor's IP address.
    If the app is behind a proxy (like on Render/Heroku/Nginx), the real
    IP is usually in the 'X-Forwarded-For' header. Otherwise we fall back
    to request.remote_addr (works fine for local testing).
    """
    forwarded = request.headers.get("X-Forwarded-For", None)
    if forwarded:
        # X-Forwarded-For can contain a list of IPs, the first is the client
        return forwarded.split(",")[0].strip()
    return request.remote_addr


def log_visit():
    """Insert one visit record into the database."""
    ip = get_visitor_ip()
    user_agent = request.headers.get("User-Agent", "Unknown")
    visited_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO logs (ip_address, user_agent, visited_at) VALUES (?, ?, ?)",
        (ip, user_agent, visited_at),
    )
    conn.commit()
    conn.close()
    return {"ip": ip, "user_agent": user_agent, "visited_at": visited_at}


@app.route("/")
def home():
    """Visitor lands here -> we log their info and show a simple page."""
    visit_info = log_visit()
    return render_template("index.html", visit_info=visit_info)


@app.route("/dashboard")
def dashboard():
    """Page that displays all logged visits in a table."""
    return render_template("dashboard.html")


@app.route("/api/logs")
def api_logs():
    """JSON API the dashboard's JavaScript calls to fetch log data."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, ip_address, user_agent, visited_at FROM logs ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()

    logs = [
        {"id": r[0], "ip_address": r[1], "user_agent": r[2], "visited_at": r[3]}
        for r in rows
    ]
    return jsonify(logs)


@app.route("/api/logs/clear", methods=["POST"])
def clear_logs():
    """Clears all logs - used by the 'Clear logs' button on the dashboard."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM logs")
    conn.commit()
    conn.close()
    return jsonify({"status": "cleared"})


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
