// This script only runs meaningful logic on the dashboard page
// (it checks if #logsBody exists before doing anything).

const logsBody = document.getElementById("logsBody");
const statusEl = document.getElementById("status");
const refreshBtn = document.getElementById("refreshBtn");
const clearBtn = document.getElementById("clearBtn");

// Fetch logs from the Flask API and render them into the table
async function loadLogs() {
  if (!logsBody) return; // not on the dashboard page

  statusEl.textContent = "Loading logs...";
  try {
    const res = await fetch("/api/logs");
    const logs = await res.json();

    logsBody.innerHTML = ""; // clear existing rows

    if (logs.length === 0) {
      logsBody.innerHTML = `<tr><td colspan="4">No visits logged yet.</td></tr>`;
    } else {
      logs.forEach((log) => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${log.id}</td>
          <td>${log.ip_address}</td>
          <td>${log.visited_at}</td>
          <td class="ua">${log.user_agent}</td>
        `;
        logsBody.appendChild(row);
      });
    }

    statusEl.textContent = `Last updated: ${new Date().toLocaleTimeString()} • ${logs.length} record(s)`;
  } catch (err) {
    statusEl.textContent = "Failed to load logs.";
    console.error(err);
  }
}

// Clear all logs (calls the Flask clear endpoint)
async function clearLogs() {
  if (!confirm("Clear all logged visits? This cannot be undone.")) return;

  try {
    await fetch("/api/logs/clear", { method: "POST" });
    await loadLogs();
  } catch (err) {
    statusEl.textContent = "Failed to clear logs.";
    console.error(err);
  }
}

if (refreshBtn) refreshBtn.addEventListener("click", loadLogs);
if (clearBtn) clearBtn.addEventListener("click", clearLogs);

// Auto-load logs as soon as the dashboard page opens
document.addEventListener("DOMContentLoaded", loadLogs);
